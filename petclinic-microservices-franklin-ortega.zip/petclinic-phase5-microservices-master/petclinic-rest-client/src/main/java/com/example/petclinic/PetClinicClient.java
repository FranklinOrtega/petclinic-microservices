package com.example.petclinic;

import com.example.petclinic.business.PetClinicBusinessWorkFlow;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class PetClinicClient {

    public static void main(String[] args) {

        ConfigurableApplicationContext context = SpringApplication.run(PetClinicClient.class, args);

        // The Bean name is the same name as the class is, first letter needs to be in lower case.
        PetClinicBusinessWorkFlow business = (PetClinicBusinessWorkFlow) context.getBean("petClinicBusinessWorkFlow");
//        SpringApplication.run(PetClinicClient.class, args);

        business.runBusiness();
    }
}

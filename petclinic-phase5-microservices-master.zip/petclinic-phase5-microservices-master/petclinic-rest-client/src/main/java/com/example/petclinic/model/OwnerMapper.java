package com.example.petclinic.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

import java.io.IOException;

public class OwnerMapper extends StdDeserializer<Owner> {


    public OwnerMapper(Class<?> vc) {
        super(vc);
    }

    @Override
    public Owner deserialize(JsonParser parser, DeserializationContext deserializer) throws IOException {
        Owner owner = new Owner();

        ObjectCodec codec = parser.getCodec();
        JsonNode node = codec.readTree(parser);

        // try catch block
        JsonNode ownerId = node.get("id");
        JsonNode ownerName = node.get("name");
        JsonNode ownerAddress = node.get("address");
        JsonNode ownerCity = node.get("city");
        JsonNode ownerPhoneNumber = node.get("phoneNumber");

        Long id = ownerId.asLong();
        String name = ownerName.asText();
        String address = ownerAddress.asText();
        String city = ownerCity.asText();
        String phoneNumber = ownerPhoneNumber.asText();

        owner.setId(id);
        owner.setName(name);
        owner.setAddress(address);
        owner.setCity(city);
        owner.setPhoneNumber(phoneNumber);

        return owner;
    }
}

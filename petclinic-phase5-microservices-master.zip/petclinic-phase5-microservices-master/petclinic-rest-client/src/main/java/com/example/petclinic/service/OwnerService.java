package com.example.petclinic.service;

import com.example.petclinic.model.Owner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.LinkedHashMap;
import java.util.List;


@Service
public class OwnerService {
    private static final Logger log = LoggerFactory.getLogger(OwnerService.class);
    RestTemplate restTemplate;

    public OwnerService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }


    // Adding an Owner
    public Owner saveOwner(Owner owner) {
        // Create an URI
        URI uri = URI.create("http://localhost:9191/ownerapi/owner/addOwner");

        // Get rest Template Response
        Owner response = restTemplate.postForObject(uri, owner, Owner.class); // This is used for add

        log.info(response.toString());

        return response;

    }

    // Updating an Owner
    public void updateOwner(Owner owner) {
        // Create an URI
        URI uri = URI.create("http://localhost:9191/ownerapi/owner/updateOwner");

        // Get rest Template Response
        restTemplate.put(uri, owner); // This is different for update, it is put

    }


    // Use delete not post
    public void deleteOwner(Owner owner) {

        // Create an URI
        URI uri = URI.create("http://localhost:9191/ownerapi/owner/deleteOwner");

        HttpEntity<Owner> entity = new HttpEntity<>(owner);

        // Delete owner
        restTemplate.exchange(uri, HttpMethod.DELETE, entity, String.class);

    }

    // Get owner by name
    public List<LinkedHashMap<String, String>> getOwnerByName(String name) {
        String uriName = name.replaceAll(" ", "%20");

        // Create an URI
        URI uri = URI.create("http://localhost:9191/ownerapi/owner/getOwnerByName/" + uriName);


        List<LinkedHashMap<String, String>> response = restTemplate.getForObject(uri, List.class);

        log.info(response.toString());

        return response;

    }

    // Get All Owners
    public List<Owner> getAllOwners() {
        // Create an URI
        URI uri = URI.create("http://localhost:9191/ownerapi/owner/getAllOwners");

        // Get all owners
        List<Owner> response = restTemplate.getForObject(uri, List.class);

        log.info(response.toString());

        return response;
    }
}
